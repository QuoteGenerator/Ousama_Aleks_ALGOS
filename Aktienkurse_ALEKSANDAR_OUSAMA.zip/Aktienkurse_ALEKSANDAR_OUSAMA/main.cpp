#include <iostream>
#include "Aktie.h"
#include "AktienHashTabelle.h"

#include <vector>
#include <fstream>
#include <sstream>


void ADD(std::vector<Aktie>& aktien);
void DELETE(std::vector<Aktie>& aktien);
void IMPORT(std::vector<Aktie>& aktien);
void SEARCH(std::vector<Aktie>& aktien);
void PLOT(std::vector<Aktie>& aktien);



void ADD_h(AktienHashTabelle& aktien_h);
void DELETE_h(AktienHashTabelle& aktien_h);
void IMPORT_h(AktienHashTabelle& aktien_h);
std::vector<kursDaten_STRUCT> extractData();
void SEARCH_h(AktienHashTabelle& aktien_h);
void PLOT_h(AktienHashTabelle& aktien_h);
void SAVE_h(AktienHashTabelle& aktien_h);
void LOAD_h(AktienHashTabelle& aktien_h);

void QUIT();
void clearTerminal();


void DEBUG(std::vector<Aktie>& aktien); //NICHT WICHTIG!!!

int main()
{
    //Liste von Aktien Objekten
    std::vector<Aktie> aktien;

    AktienHashTabelle aktien_h;


    //Menu Game Menu Menu menu MeNu unem UNEM UNEMMMM a² + b² = c²
    int eingabe = 0;
    while(1){
        //clearTerminal();
        std::cout << "\n(1): ADD; (2): DELETE; (3): IMPORT; (4): SEARCH; (5): PLOT; (6): SAVE DATA; (7): LOAD DATA; (8): QUIT;\n" << std::endl; //(10): DEBUG; wurde genutzt bei erstem Teil des Projekts
        std::cout << "Auswaehlen: "; std::cin >> eingabe;
        std::cin.ignore();
        switch(eingabe){
            case 1:
                ADD_h(aktien_h);
                //ADD(aktien);
            break;

            case 2:
                DELETE_h(aktien_h);
                //DELETE(aktien);
            break;

            case 3:
                IMPORT_h(aktien_h);
                //IMPORT(aktien);
            break;

            case 4:
                SEARCH_h(aktien_h);
                //SEARCH(aktien);
            break;

            case 5:
                PLOT_h(aktien_h);
                //PLOT(aktien);
            break;

            case 6:
                SAVE_h(aktien_h);
            break;

            case 7:
                LOAD_h(aktien_h);
            break;

            case 8:
                QUIT();
                return 0;
            break;

            case 10:
                //DEBUG(aktien);
            break;

            default:

                break;
        }
    }
    return 0;
}



void ADD_h(AktienHashTabelle& aktien_h){
    std::string aktienName = "";
    std::string aktienKuerzel = "";
    std::string WKN = "0";

    std::cout << "Aktie Name: "; std::cin >> aktienName;
    std::cout << std::endl;

    std::cout << "Aktie Kuerzel: "; std::cin >> aktienKuerzel;
    std::cout << std::endl;

    std::cout << "Aktie WKN: "; std::cin >> WKN;
    std::cout << std::endl;

    Aktie neueAktie(aktienName, aktienKuerzel, WKN);

    if(aktien_h.insert(neueAktie)){
        std::cout << "Diese Aktie wurde hinzugefuegt: " << neueAktie.getName() << std::endl;
    } else {
        std::cout << "Die gegebene Aktie konnte nicht gefunden werden!!!!!!!!!!!!!!!!" << std::endl;
    }
}
void DELETE_h(AktienHashTabelle& aktien_h){
    std::string kuerzel = "";

    std::cout << "Kuerzel der Aktie: ";
    std::cin >> kuerzel;
    std::cout << std::endl;

    if(aktien_h.remove(kuerzel)){
        std::cout << "Aktie wurde geloescht!" << std::endl;
    } else {
        std::cout << "Aktie wurde nicht gefunden!, bruh..." << std::endl;
    }
}

void IMPORT_h(AktienHashTabelle& aktien_h){

    std::string kuerzel = "";

    std::cout << "Kuerzel der Aktie: ";
    std::cin >> kuerzel;
    std::cout << std::endl;

    Aktie* aktie = aktien_h.searchByKuerzel(kuerzel);

    if(aktie == nullptr){
        std::cout << "Aktie nicht gefunden!, damn, sad life.\n";
        return;
    }

    std::vector<kursDaten_STRUCT> daten = extractData();

    aktie->updateKursDaten(daten);

    std::cout << "Das Importieren hat geklappt, lesss gooo!\n";
}

std::string readFile(){
    std::string filename;
    std::cout << "Geben Sie den Pfad zur Aktie: "; std::cin >> filename; std::cout << std::endl;

    std::ifstream file(filename, std::ios::binary | std::ios::ate);

    if(!file){
        exit(1);
    }

    std::streamsize size = file.tellg();
    file.seekg(std::ios::beg);

    std::string buffer(size, '\0');

    if(file.read(&buffer[0], size)){
        return buffer;
    }

    return std::string();
}

std::vector<kursDaten_STRUCT> extractData(){
    int reserveAmount = 30;
    kursDaten_STRUCT kursDaten;
    std::vector<kursDaten_STRUCT> daten;
    daten.reserve(reserveAmount);
    std::string buffer = readFile();

    int columnAmount = 6;
    int column = 0;
    bool entry = false;
    size_t start = buffer.find('\n') + 1; //skip first line
    for(size_t i = start; i < buffer.size(); ++i){

        if(buffer[i] == '$'){
            ++start;
            continue;
        }

        if(buffer[i] == ',' || buffer[i] == '\n'){
            std::string cell = buffer.substr(start, i - start);

            switch (column) {
                case 0: kursDaten.date = cell; break;
                case 1: kursDaten.close = std::stof(cell); break;
                case 2: kursDaten.volume = std::stol(cell); break;
                case 3: kursDaten.open = std::stof(cell); break;
                case 4: kursDaten.high = std::stof(cell); break;
                case 5: kursDaten.low = std::stof(cell); break;
            }

            column = (column + 1) % columnAmount;
            start = i + 1;
            entry = true;
        }

        if(entry && column % columnAmount == 0){
            daten.push_back(kursDaten);
            entry = false;
        }
    }
    return daten;
}

void SEARCH_h(AktienHashTabelle& aktien_h){
    int suchart = 0;
    Aktie* aktie = nullptr;

    std::cout << "\n(1): Suche nach Kuerzel\n";
    std::cout << "(2): Suche nach Name\n";
    std::cout << "Auswaehlen: ";
    std::cin >> suchart;

    if(suchart == 1){
        std::string kuerzel = "";
        std::cout << "Kuerzel der Aktie: ";
        std::cin >> kuerzel;

        aktie = aktien_h.searchByKuerzel(kuerzel);
    }
    else if(suchart == 2){
        std::string name = "";
        std::cout << "Name der Aktie: ";
        std::cin >> name;

        aktie = aktien_h.searchByName(name);
    }
    else{
        std::cout << "Ungueltige Eingabe!\n";
        return;
    }

    if(aktie == nullptr){
        std::cout << "Aktie nicht gefunden!\n";
        return;
    }

    std::vector<kursDaten_STRUCT> daten = aktie->getKursDaten();

    std::cout << "\nName: " << aktie->getName() << std::endl;
    std::cout << "Kuerzel: " << aktie->getKuerzel() << std::endl;
    std::cout << "WKN: " << aktie->getWKN() << std::endl;
    std::cout << "date, close, volume, open, high, low" << std::endl;

    if(!daten.empty()){
        kursDaten_STRUCT aktuellsterKurs = daten.front();

        std::cout << aktuellsterKurs.date << " ";
        std::cout << aktuellsterKurs.close << " ";
        std::cout << aktuellsterKurs.volume << " ";
        std::cout << aktuellsterKurs.open << " ";
        std::cout << aktuellsterKurs.high << " ";
        std::cout << aktuellsterKurs.low << std::endl;
    }
    else{
        std::cout << "Kursdaten, NOT vorhanden\n";
    }
}

void PLOT_h(AktienHashTabelle& aktien_h){
    std::string kuerzel;

    std::cout << "Kuerzel der Aktie: ";
    std::cin >> kuerzel;

    Aktie* aktie = aktien_h.searchByKuerzel(kuerzel);

    if(aktie == nullptr){
        std::cout << "Alle Aktien sind verschwunden, keine zu finden!\n";
        return;
    }

    std::vector<kursDaten_STRUCT> kurse = aktie->getKursDaten();

    if(kurse.empty()){
        std::cout << "Keine Kursdaten vorhanden!\n";
        return;
    }

    std::cout << "\nASCII-Grafik der Schlusskurse von " << aktie->getName() << ":\n";

    int scale = 4;

    for(size_t i = 0; i < kurse.size(); i++){ //nicht i < 30 gemacht, weil csv datei, nicht einen ganzen monat hat, sondern nur von 01.03.-16.03.
        std::string bar;

        int length = static_cast<int>(kurse[i].close / scale); // von float zu integer, also z.B. 62,55 wird zu 62   ------ ist etwas cleaner ;) :D ;D :|

        for(int j = 0; j < length; j++){
            bar += '#';
        }

        std::cout << kurse[i].date << " " << kurse[i].close << " " << bar << std::endl;
    }

    std::cout << std::endl;
}

void SAVE_h(AktienHashTabelle& aktien_h){
    std::string filename = "";

    std::cout << "Wo soll es gespeichert werden. SAG!: ";
    std::cin >> filename;
    std::cout << std::endl;

    std::ofstream file(filename);

    if(!file){
        std::cout << "KEINE RECHTE! SOMIT NICHT KREIRT/GEFUNDEN, ODER ETWAS ANDERS, anderes..., ODER ODER.... idk" << std::endl;
        return;
    }

    std::vector<Aktie> alleAktien = aktien_h.getAllAktien();

    for(int i = 0; i < alleAktien.size(); i++){
        file << alleAktien[i].getName() << ";" << alleAktien[i].getKuerzel() << ";" << alleAktien[i].getWKN() << std::endl;
    }

    file.close();

    std::cout << "Hashtabelle ist an einem sicheren ort (GESPEICHERT) :D !" << std::endl;
}

void LOAD_h(AktienHashTabelle& aktien_h){
    std::string filename = "";

    std::cout << "Wie heißt die Datei?: ";
    std::cin >> filename;
    std::cout << std::endl;

    std::ifstream file(filename);

    if(!file){
        std::cout << "Datei gibt es nicht, probably schreibfehler oder so..... BITTE 100% GEORG RICHTER für diese Abgabe... DANKE :-D " << std::endl;
        return;
    }

    std::string line = "";

    while(std::getline(file, line)){
        std::stringstream ss(line);

        std::string name = "";
        std::string kuerzel = "";
        std::string wkn = "";

        std::getline(ss, name, ';');
        std::getline(ss, kuerzel, ';');
        std::getline(ss, wkn, ';');

        Aktie neueAktie(name, kuerzel, wkn);
        aktien_h.insert(neueAktie);
    }

    file.close();

    std::cout << "ALLE AKTIEN WURDEN GELADEN, bzw. DIE HASHTABELLLLLLEEEEEEEEEE!!!" << std::endl;
}

void QUIT(){
    std::cout << "Goodbye!!!";
}




/*
void ADD(std::vector<Aktie>& aktien){
    std::string aktienName = "";
    std::string aktienKuerzel = "";
    std::string WKN = "0";

    std::cout << "Geben Sie den Namen der Aktie an: "; std::cin >> aktienName; std::cout << std::endl;
    std::cout << "Geben Sie den Kuerzel der Aktie an: "; std::cin >> aktienKuerzel; std::cout << std::endl;
    std::cout << "Geben Sie die WKN an: "; std::cin >> WKN; std::cout << std::endl;

    aktien.emplace_back(aktienName, aktienKuerzel, WKN);

    std::cout << "Folgende Aktie wurde hinzugefuegt: " << aktien.back().getName() << std::endl;
}

void DELETE(std::vector<Aktie>& aktien){
    std::string nameEingabe = "";
    std::cout << "Geben Sie den Namen der Aktie ein: "; std::cin >> nameEingabe; std::cout << std::endl;
    for(size_t i = 0; i < aktien.size(); i++){
        if(aktien[i].getName() == nameEingabe){
            aktien.erase(aktien.begin()+i);
            break;
        }
    }
}

void SEARCH(std::vector<Aktie>& aktien){
    int SEARCH_eingabe = 0;
    std::string gesuchteAktie = "";

    while(1){
        std::cout << "\n(1): Aktie Zeigen!; (2): SEARCH schliessen;\n" << std::endl;
        std::cout << "Waehlen Sie aus: ";
        std::cin >> SEARCH_eingabe;

        if(aktien.empty()){
            std::cout << "Keine Aktien vorhanden!\n";
            return;
        }

        if(SEARCH_eingabe == 1){
            std::cout << "\nGeben Sie den Namen der Aktie ein: ";
            std::cin >> gesuchteAktie;

            bool gefunden = false;

            for(auto i = aktien.begin(); i != aktien.end(); i++){
                if(gesuchteAktie == i->getName()){
                    gefunden = true;

                    std::cout << i->getName() << std::endl;
                    std::cout << "date, close, volume, open, high, low" << std::endl;

                    auto daten = i->getKursDaten();

                    if(!daten.empty()){
                        kursDaten_STRUCT datenpaket = daten.front();

                        std::cout << datenpaket.date << " ";
                        std::cout << datenpaket.close << " ";
                        std::cout << datenpaket.volume << " ";
                        std::cout << datenpaket.open << " ";
                        std::cout << datenpaket.high << " ";
                        std::cout << datenpaket.low << std::endl;
                    } else {
                        std::cout << "Keine Kursdaten vorhanden!\n";
                    }

                    break; // wichtig → wir haben sie gefunden
                }
            }

            if(!gefunden){
                std::cout << "Aktie gibt es nicht!\n";
            }
        }
        else if(SEARCH_eingabe == 2){
            break;
        }
    }
}








void IMPORT(std::vector<Aktie>& aktien){

    std::string nameInput = "";

    std::cout << "Geben Sie den Namen der Aktie ein: "; std::cin >> nameInput; std::cout << std::endl;

    //check if found first

    for(auto& aktie : aktien){
        if(aktie.getName() == nameInput){
            aktie.updateKursDaten(extractData());
        }
    }
}

void PLOT(std::vector<Aktie>& aktien){

    std::string name;
    std::cout << "Geben Sie den Namen der Aktie ein: ";
    std::cin >> name;
    std::cout << '\n';

    //check if found first

    int scale = 4;
    for(Aktie aktie : aktien){
        if(aktie.getName() == name){
            std::cout << "ASCII-Grafik der Schlusskurse von " << aktie.getName() << '\n';
            std::vector<kursDaten_STRUCT> kurse = aktie.getKursDaten();
            for(size_t i = 0; i < kurse.size(); ++i){
                std::string bar;
                bar.reserve(6);
                std::string date = kurse[i].date;
                float close = kurse[i].close;

                int length = close / scale;

                for (int i = 0; i < length; i++) {
                    bar += '#';
                }

                std::cout << date << ' ' << close << ' ' << bar << '\n';
            }
        }
    }
}



void DEBUG(std::vector<Aktie>& aktien){
    int DEBUG_eingabe = 0;
    while(1){
        std::cout << "\n(1): Aktien Zeigen!; (2): DEBUG schliessen;\n" << std::endl;
        std::cout << "Waehlen Sie aus: "; std::cin >> DEBUG_eingabe;
        if(DEBUG_eingabe == 1){
            for(auto i = aktien.begin(); i != aktien.end(); i++){
                std::cout << i->getName() << std::endl;
                std::cout << "date, close, volume, open, high, low" << std::endl;
                kursDaten_STRUCT datenpaket;
                auto daten = i->getKursDaten();
                if(!daten.empty()){
                    for(auto it = daten.begin(); it != daten.end(); it++){
                        datenpaket = *it;
                        std::cout << datenpaket.date << " ";
                        std::cout << datenpaket.close << " ";
                        std::cout << datenpaket.volume << " ";
                        std::cout << datenpaket.open << " ";
                        std::cout << datenpaket.high << " ";
                        std::cout << datenpaket.low << " " << std::endl;
                    }
                }
            }
            continue;
        }else if(DEBUG_eingabe == 2){
            break;
        }
    }
}

void clearTerminal(){
    for(int i = 0; i < 20; i++){
        std::cout << "\033[A\r\033[K";
    }
}
*/



